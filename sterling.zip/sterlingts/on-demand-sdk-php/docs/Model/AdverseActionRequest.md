# AdverseActionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**comment** | **string** | Text explaining the reason for the adverse action (not every item can take a reason) | [optional] 
**report_item_ids** | **string[]** | List of report item ids that are involved with the adverse action | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


