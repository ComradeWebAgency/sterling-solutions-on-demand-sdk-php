# PackageResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **bool** |  | [optional] 
**components** | **string[]** |  | [optional] 
**id** | **string** |  | [optional] 
**required_fields** | **string[]** |  | [optional] 
**supported** | **bool** |  | [optional] 
**title** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


