# DriversLicense

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**issuing_agency** | **string** |  | [optional] 
**license_number** | **string** |  | [optional] 
**type** | **string** | driver&#39;s license type (personal or commercial) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


