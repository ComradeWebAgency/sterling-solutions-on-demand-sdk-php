# VerificationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kba** | [**\Oda\Client\Model\KnowledgeBasedAnswer**](KnowledgeBasedAnswer.md) | The answers to the verification questions | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


