# ScreeningDetailsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**completed_at** | [**\DateTime**](\DateTime.md) |  | [optional] 
**disclosure_details** | **string** |  | [optional] 
**id** | **string** |  | [optional] 
**reason** | **string** |  | [optional] 
**result** | **string** |  | [optional] 
**result_statement** | **string** |  | [optional] 
**status** | **string** |  | [optional] 
**type** | **string** |  | [optional] 
**updated_at** | [**\DateTime**](\DateTime.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


