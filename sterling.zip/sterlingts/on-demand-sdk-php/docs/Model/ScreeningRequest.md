# ScreeningRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**billing_code** | **string** |  | [optional] 
**callback** | [**\Oda\Client\Model\CallbackRequest**](CallbackRequest.md) |  | [optional] 
**candidate_id** | **string** |  | [optional] 
**charge_id** | **string** |  | [optional] 
**end_user_certificate** | **string** |  | [optional] 
**invite** | [**\Oda\Client\Model\Invite**](Invite.md) |  | [optional] 
**package_id** | **string** |  | [optional] 
**reference_codes** | [**\Oda\Client\Model\ReferenceCode[]**](ReferenceCode.md) |  | [optional] 
**trusted_user_id** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


