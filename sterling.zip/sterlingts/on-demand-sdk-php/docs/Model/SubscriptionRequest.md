# SubscriptionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**schedule** | [**\Oda\Client\Model\Schedule**](Schedule.md) |  | [optional] 
**screening** | [**\Oda\Client\Model\ScreeningRequest**](ScreeningRequest.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


