# Answer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**question_id** | **string** | The ID of the question that this is answering | [optional] 
**response** | **string** | The correct answer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


