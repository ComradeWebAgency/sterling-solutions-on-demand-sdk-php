# BillingCodesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**billing_codes** | **string[]** | A list of billing codes | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


