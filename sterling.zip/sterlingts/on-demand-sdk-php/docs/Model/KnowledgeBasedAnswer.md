# KnowledgeBasedAnswer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answers** | [**\Oda\Client\Model\Answer[]**](Answer.md) |  | [optional] 
**questions** | [**\Oda\Client\Model\Question[]**](Question.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


