# CallbackCredentials

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**basic_auth** | **string** | Basic Auth credentials. In a &#39;username:password&#39; format. (eg &#39;narf:zort!&#39; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


