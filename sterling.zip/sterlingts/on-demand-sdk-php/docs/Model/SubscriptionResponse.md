# SubscriptionResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | [**\DateTime**](\DateTime.md) |  | [optional] 
**id** | **string** |  | [optional] 
**metrics** | [**\Oda\Client\Model\Metrics**](Metrics.md) |  | [optional] 
**next_run_at** | [**\DateTime**](\DateTime.md) |  | [optional] 
**schedule** | [**\Oda\Client\Model\Schedule**](Schedule.md) |  | [optional] 
**screening** | [**\Oda\Client\Model\ScreeningRequest**](ScreeningRequest.md) |  | [optional] 
**status** | **string** |  | [optional] 
**updated_at** | [**\DateTime**](\DateTime.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


