# CallbackRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credentials** | [**\Oda\Client\Model\CallbackCredentials**](CallbackCredentials.md) | The type of authentication to use when the callback occurs | [optional] 
**uri** | **string** | The URI that the callback will call | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


