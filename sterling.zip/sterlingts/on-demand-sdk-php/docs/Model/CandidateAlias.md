# CandidateAlias

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**confirmed_no_middle_name** | **bool** | Set to &#39;True&#39; if the Candidate has no alternate middle name | [optional] 
**family_name** | **string** | The Candidate&#39;s alternate last name | [optional] 
**given_name** | **string** | The Candidate&#39;s alternate first name | [optional] 
**middle_name** | **string** | The Candidate&#39;s alternate middle name | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


